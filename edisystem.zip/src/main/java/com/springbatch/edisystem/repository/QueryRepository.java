package com.springbatch.edisystem.repository;

import com.springbatch.edisystem.domain.QuerySetting;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by youngjae on 2018. 3. 3..
 */
@Repository
public interface QueryRepository extends JpaRepository<QuerySetting, Long> {
	
    QuerySetting findById(int id);
}
