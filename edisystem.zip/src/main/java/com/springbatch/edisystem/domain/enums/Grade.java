package com.springbatch.edisystem.domain.enums;

public enum Grade {
    VIP, GOLD, FAMILY
}
